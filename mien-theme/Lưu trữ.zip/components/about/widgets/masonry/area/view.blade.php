<div class="masonry-section">
    <div class="masonry-inner">
        {!! $children !!}
    </div>
</div>