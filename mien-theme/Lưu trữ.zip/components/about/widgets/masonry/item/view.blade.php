@php
    
@endphp
<div class="masonry-item width-{{$data->width}} height-{{$data->height}}">
    <div class="masonry-item-box">
        <a href="javascript:void(0)" class="masonry-link">
            <img src="{{$data->image}}" alt="{{$data->title}}">
        </a>
    </div>
</div>