<div class="banner-item">
    <a href="{{$data->url}}">
        <img src="{{$data->image}}" alt="{{$data->title}}" class="banner-image">
    </a>
</div>