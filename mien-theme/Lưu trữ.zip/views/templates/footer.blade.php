<div class="footer-spactor">
    
</div>
<footer class="footer mien-footer">
    <div class="container">
        <div class="row">
            {!! $html->footer_widgets->components !!}
        </div>
    </div>
</footer>