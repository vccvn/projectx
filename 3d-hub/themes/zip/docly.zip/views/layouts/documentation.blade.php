<!doctype html>
<html lang="en">
<head>
    @include($_lib.'head')
</head>


@php

    $header = $options->theme->header;

    $body_class = 'doc full-width-doc';
    $body_wrapper_class = '';
    $headerStyle = isset($header_style)?$header_style:(
        $__env->yieldContent('header_style', $postSettings->header_style(1))
    );
    $stickyMenu = isset($sticky_menu)?$sticky_menu:(
        $__env->yieldContent('sticky_menu', null)
    );

    if($stickyMenu || $headerStyle == 3){
        $headerStyle = 3;
        $stickeMenu = 1;
        $body_wrapper_class = 'sticky_menu';
        $body_class .= ' sticky-nav-doc';
    }

    $showRightMenu = (isset($show_right_menu) && $show_right_menu) || (($srm = $__env->yieldContent('show_right_menu')) && $srm);
@endphp

<body data-spy="scroll" data-target="#navbar-example3" data-offset="86" data-scroll-animation="true"  class="{{$body_class}}">
    {!! $html->top->embeds !!}
    @include($_template.'preloader')

    <div class="body_wrapper {{$body_wrapper_class}}">
        @include($_template.'headers.doc')
        @if (!$stickyMenu)
        @include($_template.'page-header.doc')
        @include($_template.'breadcrumb')
        @endif
        
        

        <section class="doc_documentation_area doc_documentation_full_area {{$stickyMenu?'body_fixed':''}}" @if (!$stickyMenu) id="sticky_doc" @endif>
            <div class="overlay_bg"></div>
            <div class="container-fluid pl-60 pr-60">
                <div class="row">
                    <div class="col-lg-3 doc_mobile_menu {{$stickyMenu?'':'display_none'}}">
                        @include($_template.'sidebars.doc-left')
                    </div>
                    @if ($showRightMenu)
                        <div class="col-lg-7 col-md-8">
                            @yield('content')
                        </div>
                        <div class="col-lg-2 col-md-4 doc_right_mobile_menu">
                            @include($_template.'sidebars.doc-right')
                        </div>
                        
                    @else
                        <div class="col-lg-9 col-md-12">
                            @yield('content')
                        </div>
                    
                    @endif
                </div>
            </div>
        </section>
        @include($_template.'footers.style-2')
    </div>
    @include($_template.'modals')
    <!-- Optional JavaScript -->
    @include($_template.'js')
</body>



</html>