<!doctype html>
<html lang="en">
<head>
    @include($_lib.'head')
</head>


<body data-scroll-animation="true">

    {!! $html->top->embeds !!}

    @include($_template.'preloader')
    @php
        $option = $options->theme->services;
    @endphp
    <div class="body_wrapper">
        
        @include($_template.'headers.style-1')
        {{-- @include($_template.'page-header.service') --}}
        @if ($option->show_breadcrumb)
            
            @include($_template.'breadcrumb')
            
        @endif
        @yield('content')
        
        @include($_template.'footers.style-1')
    </div>
    <!-- Optional JavaScript -->
    @include($_template.'js')
</body>



</html>