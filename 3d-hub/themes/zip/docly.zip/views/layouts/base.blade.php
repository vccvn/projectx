<!doctype html>
<html lang="en">
<head>
    @include($_lib.'head')
</head>


<body data-scroll-animation="true">

    {!! $html->top->embeds !!}

    @include($_template.'preloader')

    <div class="body_wrapper">
        @include($_template.$__env->yieldContent('header_template', 'master.header'))
        {{-- @include($_template.'breadcrumb') --}}
        @yield('content')
        
        @include($_template.$__env->yieldContent('footer_template', 'master.footer'))
    </div>
    <!-- Optional JavaScript -->
    @include($_template.'js')
</body>



</html>