@php
    $dynamic_type = 'post';
    if($dynamicSettings = get_docly_dynamic_settings($dynamic->id)){
        $dynamic_type = $dynamicSettings->dynamic_type;
        $postSettings = $dynamicSettings;
    }
@endphp
@include($_current.$dynamic_type.'.empty')
