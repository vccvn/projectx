@extends($_layout.'documentation')
@include($_lib.'register-meta')
@section('sticky_menu', 1)
@section('show_right_menu', 1)
@section('content')
@php
    set_docly_bookmark($article->bookmark);
@endphp
<article class="documentation_body" id="documentation">
    <div class="shortcode_title">
        <h2>{{$article->title}}</h2>
    </div>
</article>
<div class="border_bottom"></div>

<article class="post-content">
    {!! $article->content !!}
</article>

<div class="border_bottom"></div>
{!! $html->post_docs->components !!}
@endsection
@section('css')
    
<link rel="stylesheet" href="{{theme_asset('assets/prism/prism.css')}}">
<link rel="stylesheet" href="{{theme_asset('assets/prism/prism-coy.css')}}">
@endsection
@section('js')
    
<script src="{{theme_asset('assets/prism/prism.js')}}"></script>
@endsection