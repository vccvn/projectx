@php
    $isNotHomeDoc = (isset($category) && $category) || (!$request->s && $request->page && is_numeric($request->page) && $request->page > 1 );
@endphp
@extends($_layout.'documentation')
@if ($isNotHomeDoc)
    @section('sticky_menu', 1)
@endif
@include($_lib.'register-meta')

@section('content')
<article class="documentation_body" id="documentation">
    <div class="shortcode_title">
        <h2>{{$page_title}}</h2>
        <p>{!! (isset($category) && $category)?$category->description:$dynamic->description !!}</p>
    </div>
    @if (count($posts))
    <div class="row">
        @foreach ($posts as $post)
        <div class="col-md-4 col-sm-6">
            <div class="media documentation_item">
                <div class="icon">
                    <a href="{{$u = $post->getViewUrl()}}">
                        <img src="{{$post->getImage('90x90')}}" alt="{{$post->title}}">
                    </a>
                </div>
                <div class="media-body">
                    <a href="{{$u}}">
                        <h5>{{$post->title}}</h5>
                    </a>
                    <p>{{$post->getShortDesc(120)}}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    {{$posts->links($_template.'pagination')}}
    @else
    <div class="row mb-150">
        <div class="col-lg-12 ">
            <div class="alert alert-warning text-center">
                Không có kết quả phù hợp
            </div>
        </div>
        
    </div>
    
    
    @endif
    
</article>

<div class="border_bottom"></div>


@if ($isNotHomeDoc)
    {!! $html->home_docs->components !!}
@else
    {!! $html->post_docs->components !!}
@endif

@endsection