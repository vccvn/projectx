@extends($_layout.'posts')
@section('sub_layout',$list_layout)
@include($_lib.'register-meta')

@section('content')
    @if ($list_type == 'list')
        @if (count($posts))
            @foreach ($posts as $post)
            @php
                $post->applyMeta();
                $url = $post->getViewUrl();
                $image = $post->getImage('770x400');
                $post_title = $post->title
            @endphp
            <div class="blog_top_post blog_classic_item">
                @if ($post->contentType('video_embed') || $post->contentType('video'))
                <div class="video_post">
                    <img class="post-thumbnail" src="{{$image}}" alt="{{$post_title}}">
                    <a class="popup-youtube video_icon" href="{{$url}}"><i class="arrow_triangle-right"></i></a>
                </div>
                @else
                    <a href="{{$url}}">
                        <img class="post-thumbnail" src="{{$image}}" alt="{{$post_title}}">
                    </a>
                @endif
                
                <div class="b_top_post_content">
                    <div class="post_tag">
                        <a href="{{$url}}">{{$post->timeAgo()}}</a>
                            @if ($post->category)
                            <a class="green" href="{{$post->category->getViewUrl()}}">{{$post->category->name}}</a>    
                            @elseif(count($post->tags))
                                @foreach ($post->tags as $tag)
                                    @if ($loop->index < 2)
                                        <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                    @endif
                                @endforeach
                            
                            @endif
                            
                    </div>
                    <a href="{{$url}}">
                        <h4 class="b_title">{{$post->title}}</h4>
                    </a>
                    <p>{{$post->getShortDesc(150)}}</p>
                    <div class="d-flex justify-content-between p_bottom">
                        <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a>
                        @if ($post->author)
                            
                        <div class="media post_author">
                            <div class="round_img">
                                <img src="{{$post->author->getAvatar()}}" alt="">
                            </div>
                            <div class="media-body author_text">
                                <a href="#">
                                    <h4>{{$post->author->name}}</h4>
                                </a>
                            </div>
                        </div>
                        
                        @endif
                    </div>
                </div>
            </div>
            @endforeach

            {{$posts->links($_template.'pagination')}}

        @else
            <div class="alert alert-warning">Không có kết quả phù hợp</div>
        @endif
    @else
        @php
            $item_class = $list_layout == 'fullwidth' ? 'col-lg-4 col-sm-6' : 'col-sm-6';
        @endphp
        @if (count($posts))
            <div class="row">

                @foreach ($posts as $post)
                @php
                    $post->applyMeta();
                    $url = $post->getViewUrl();
                    $image = $post->getImage('thumbnail');
                    $post_title = $post->title
                @endphp
                <div class="{{$item_class}}">
                    <div class="blog_grid_post wow fadeInUp">
                        @if ($post->contentType('video_embed') || $post->contentType('video'))
                        <div class="video_post">
                            <img class="post-thumbnail" src="{{$image}}" alt="{{$post_title}}">
                            <a class="popup-youtube video_icon" href="{{$url}}"><i class="arrow_triangle-right"></i></a>
                        </div>
                        @else
                            <a href="{{$url}}">
                                <img class="post-thumbnail" src="{{$image}}" alt="{{$post_title}}">
                            </a>
                        @endif
                        
                        <div class="grid_post_content">
                            <div class="post_tag">
                                <a href="{{$url}}">{{$post->timeAgo()}}</a>
                                    @if ($post->category)
                                    <a class="green" href="{{$post->category->getViewUrl()}}">{{$post->category->name}}</a>    
                                    @elseif(count($post->tags))
                                        @foreach ($post->tags as $tag)
                                            @if ($loop->index < 2)
                                                <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                            @endif
                                        @endforeach
                                    
                                    @endif
                                    
                            </div>
                            <a href="{{$url}}">
                                <h4 class="b_title">{{$post->title}}</h4>
                            </a>
                            <p>{{$post->getShortDesc(100)}}</p>
                                {{-- <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a> --}}
                                @if ($post->author)
                                        
                                    <div class="media post_author">
                                        <div class="round_img">
                                            <img src="{{$post->author->getAvatar()}}" alt="">
                                        </div>
                                        <div class="media-body author_text">
                                            <a href="#">
                                                <h4>{{$post->author->name}}</h4>
                                            </a>
                                        </div>
                                    </div>
                                
                                @endif
                        </div>
                    </div>
                </div>

                @endforeach
    
                

            </div>
            
            {{$posts->links($_template.'pagination')}}
        @else
        <div class="alert alert-warning">Không có kết quả phù hợp</div>
        @endif
    @endif
@endsection