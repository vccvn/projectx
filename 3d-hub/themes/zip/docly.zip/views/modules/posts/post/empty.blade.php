@extends($_layout.'posts')

@section('sub_layout',$list_layout)

@include($_lib.'register-meta')

@section('content')
    <div class="alert alert-warning">Không có kết quả phù hợp</div>
@endsection