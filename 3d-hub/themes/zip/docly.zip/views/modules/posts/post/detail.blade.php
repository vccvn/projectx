@php
    
    $detailSettings = $postSettings->makeByPrefix('detail_');
@endphp

@extends($_layout.'posts')
@section('sub_layout','sidebar')
@include($_lib.'register-meta')

@php

    $u = $article->getViewUrl();
    
@endphp

@if ($detailSettings->use_feature_image)
    @section('page_header_bg_image', $article->getImage())
@endif

@if ($article->service_id && $service = $helper->getService(['id' => $article->service_id, '@with' => ['packages']]))
                
    @if (count($service->packages))
        @section('pricing_table')
        <div id="pricing-service-{{$service->id}}">
            @php
                $active_type = $article->featured_package?$article->featured_package:'pro';
            @endphp
            @include($_template.'pricing.item')
        </div>

        
        @endsection
    @endif
@endif

@if (($article->contentType('gallery') || $dynamic->post_type == 'gallery') && $galleries = $article->gallery)
    @if (count($galleries))
        @section('gallery')
            <div class="post-gallery docly-carousel owl-carousel owl-theme" data-show="1" data-dots="true" data-autoplay="true" data-speed="500" data-nav="true" data-loop="true">
                @foreach ($galleries as $item)
                <div class="item">
                    <img class="img-responsive" src="{{$item->getUrl()}}">
                </div>
                @endforeach
            </div>
        @endsection
    @endif
@endif

@php
    $gallery = $__env->yieldContent('gallery');
    $pricing_table = $__env->yieldContent('pricing_table');
    $content = '<div class="post-content">
                    '.$article->content.'
                </div>';
    
    if($gallery || $pricing_table){
        $args = [];
        if($gallery){
            if(preg_match('/[^\{}]\{\$gallery\}[^\}]/i', $content)){
                $args['gallery'] = $gallery;
            }else{
                $content = $gallery.$content;
            }
        }
        if($pricing_table){
            if(preg_match('/[^\{}]\{\$pricing_table\}[^\}]/i', $content)){
                $args['pricing_table'] = $pricing_table;
            }else{
                $content .= $pricing_table;
            }
        }
        $content = str_eval($content, $args);

    }
@endphp


@section('content')
        
<div class="blog_single_info">
    <div class="blog_single_item">
        @if ($article->contentType('embed') && $video = $article->getVideo())
            <div class="embed-responsive embed-responsive-16by9 mb-2">
                <iframe class="embed-responsive-item" src="{{$video->embed_url}}" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
            </div>
            {!! $content !!}
        
        @else
            @if (!$detailSettings->hide_feature_image)
                
                <a href="{{$u}}" class="blog_single_img">
                    <img src="{{$article->getImage()}}" alt="{{$article->title}}" class="post-thumbnail">
                </a>
                
            @endif
            {!! $content !!}
        
        @endif
        @include($_template.'share',[
            'title' => $article->title,
            'link' => $u,
            'description' => $article->getShortDesc(150),
            'image' => $article->getImage('social')
        ])
    </div>
    {{-- <div class="blog_post_author media">
        <div class="author_img">
            <img src="img/blog-single/author.jpg" alt="">
        </div>
        <div class="media-body">
            <h5>Jason Response</h5>
            <p>Loo tomfoolery jolly good bloke chancer chimney pot nice one a, he nicked it mufty Oxford say wind up bits and bobs cheeky bugger, amongst cack bugger Eaton William skive off.!</p>
        </div>
    </div> --}}


    @include($_template.'related', [
        'list_title' => 'Có thể bạn quan tâm',
        'posts' => $article->getRelated(3)
    ])


    @include($_template.'comments',[
        'comments' => $article->publishComments,
        'ref' => $article->type,
        'ref_id' => $article->id,
        'url' => $article->getViewUrl()
    ])

</div>


@endsection