@php
    $postSettings = $options->theme->posts;
    $list_layout = $postSettings->list_layout;
    $breadcrumb = $postSettings->show_breadcrumb;
    $list_type = $postSettings->list_type('grid');
    $dynamic_type = 'post';
    if($dynamicSettings = get_docly_dynamic_settings($dynamic->id)){
        $list_layout = $dynamicSettings->list_layout;
        $breadcrumb = $dynamicSettings->show_breadcrumb;
        $list_type = $dynamicSettings->list_type;
        $dynamic_type = $dynamicSettings->dynamic_type;
        $postSettings = $dynamicSettings;
    }
@endphp
@include($_current.$dynamic_type.'.list')
