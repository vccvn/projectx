@php
    $pageSettings = $options->theme->pages;
    $list_layout = $pageSettings->list_layout;
    $breadcrumb = $pageSettings->show_breadcrumb;
    $list_type = $pageSettings->list_type('grid');
    $detailSettings = $pageSettings->makeByPrefix('detail_');
@endphp

@extends($_layout.'pages')
@section('sub_layout','fullwidth')
@include($_lib.'register-meta')

@php
    $u = $article->getViewUrl();
    
@endphp

@if ($detailSettings->use_feature_image)
    @section('page_header_bg_image', $article->getImage())
@endif



@section('content')
        
<div class="blog_single_info">
    <div class="blog_single_item">
        
        @if (!$detailSettings->hide_feature_image)
            
            <a href="{{$u}}" class="blog_single_img">
                <img src="{{$article->getImage()}}" alt="{{$article->title}}" class="post-thumbnail">
            </a>
            
        @endif
            <div class="post-content">
                {!! $article->content !!}
            </div>
    
        @include($_template.'share',[
            'title' => $article->title,
            'link' => $u,
            'description' => $article->getShortDesc(150),
            'image' => $article->getImage('social')
        ])
    </div>
    {{-- <div class="blog_post_author media">
        <div class="author_img">
            <img src="img/blog-single/author.jpg" alt="">
        </div>
        <div class="media-body">
            <h5>Jason Response</h5>
            <p>Loo tomfoolery jolly good bloke chancer chimney pot nice one a, he nicked it mufty Oxford say wind up bits and bobs cheeky bugger, amongst cack bugger Eaton William skive off.!</p>
        </div>
    </div> --}}


    @if (!$detailSettings->hide_related)
        
        @include($_template.'related', [
            'list_title' => 'Có thể bạn quan tâm',
            'posts' => $article->getRelated(3)
        ])

    @endif


    @if (!$detailSettings->hide_comments)
        
        @include($_template.'comments',[
            'comments' => $article->publishComments,
            'ref' => $article->type,
            'ref_id' => $article->id,
            'url' => $article->getViewUrl()
        ])

    @endif
</div>


@endsection

