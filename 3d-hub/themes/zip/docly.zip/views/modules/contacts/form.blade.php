@php
    $contacts = $options->theme->contacts;
    $title = $contacts->page_title('Liên hệ');
    $socials = $options->theme->socials;
    $list = ['facebook', 'twitter', 'instagram', 'youtube', 'linkedin'];

@endphp
@extends($_layout.'master',[
    'page_title' => $title, 
    'show_breadcrumb' =>  1
])
@include($_lib.'register-meta')
@section('title', $title)

@if ($contacts->page_description)
    
@section('meta_description', $contacts->page_description)
    
@endif
@section('content')
@include($_template.'breadcrumb-2')

<section id="contact" class="contact-us-section contact_area sec_pad">
    <div class="container">
        
        <div class="contact-us-content blog_comment_box mt-0 pt-0">
            <div class="row">
                <div class="col-md-5">
                    <div class="headingOne text-center">
                        <h3>Thông tin liên hệ</h3>
                    </div>
                    
                    <div class="footer-address mb-20">
                        <ul>
                            <li class="icolor-1">
                                <i class="fa fa-map-marker"></i> <span>{{$contacts->address($siteinfo->address)}}</span>
                            </li>
                            <li class="icolor-3">
                                <i class="fa fa-phone"></i>
                                <span>Điện thoại: <a href="tel:{{$phone = $contacts->phone_number($siteinfo->phone_number('094.578.6960'))}}">{{$phone}}</a></span>
                            </li>

                            <li class="icolor-2">
                                <i class="fa fa-envelope"></i> 
                                <span>Email : 
                                <a href="mailto:{{$email = $contacts->email($siteinfo->email('doanln.chinhlatoi@gmail.com'))}}">{{$email}}</a>
                                </span>
                            </li>
                            @foreach ($list as $item)
                                @if ($link = $socials->get($item))
                                    <li class="">
                                        <i class="social_{{$item}}"></i>
                                        <span>{{ucfirst($item)}}: <a href="{{$link}}">{{$link}}</a></span>
                                    </li>
                                @endif
                            @endforeach
                        </ul>
                    </div>
                </div>

                <div class="col-md-7">
                    <div class="headingOne text-center">
                        <h3>Gửi liên hệ</h3>
                    </div>
                    
                    <form id="contactForm1" method="POST" action="{{route('client.contacts.send')}}" data-ajax-url="{{route('client.contacts.ajax-send')}}" class="{{parse_classname('contact-form1')}} get_quote_form pt-0 mt-0">
                        @csrf
                        <input type="hidden" name="response_type" value="text">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <input id="name" name="name" type="text" class="form-control" required="" placeholder="Your name / Họ và tên *">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input id="email1" name="email" type="email" class="form-control" required="" placeholder="Your email / Địa chỉ e-mail *">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input id="phone" name="phone_number" type="tel" class="form-control" placeholder="Your phone / Số điện thoại">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <textarea id="message1" name="message" class="form-control" placeholder="Message / Nội dung *"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn action_btn thm_btn">{{$contacts->button_text('Send message')}}</button>
                        </div>
                    </form>
                    <p class="form-message"></p>
                </div>
            </div>
        </div>
    </div>

</section>

{{-- <section class="contact_area sec_pad">
    <div class="container">
        

    </div>
</section> --}}














    <!-- Start Google Maps 
    ============================================= -->
    <div class="maps-area">
        <div class="container-full">
            <div class="row">
                <div class="google-maps">
                    {!! $contacts->map_code !!}
                </div>
            </div>
        </div>
    </div>
    <!-- End Google Maps -->

@endsection