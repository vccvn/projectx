@php
    $settings = get_account_setting_configs();
    // $form = $helper->getServiceForm();
@endphp
@extends($_layout.'services',[
    'page_title' => "Thanh toán dịch vụ", 
    'show_breadcrumb' =>  1,
    // 'breadcrumb_type' => 2
])
@section('title', "Thanh toán dịch vụ")
@include($_lib.'register-meta')
@section('content')
    <div class="contact_area sec_pad ">
        <div class="container">
            <div class="form-section">
                <div class="ps-section__content">
                    @if (!session('user_service_id'))
                    <div class="ps-form--order-tracking bg-white">
                        <form class="form crazy-form" action="{{route('client.services.check-payment')}}" method="POST">
                                @csrf
                                @if ($error = session('error'))
                                    <div class="alert alert-danger text-center">
                                        {{$error}}
                                    </div>
                                @endif
                
                                <div class="form-group">
                                    <label class="form__label" for="user_service_id">
                                        Mã dịch vụ <span>*</span>
                                    </label>
                                    <input type="text" name="user_service_id" class="form-control" value="{{old('user_service_id')}}" placeholder="Mã dịch vụ">
                                </div>
                                @if ($error = $errors->first('user_service_id'))
                                    <div class="alert alert-danger text-center">
                                        {{$error}}
                                    </div>
                                @endif
                                <div class="form-group submit">
                                    <button type="submit" class="btn btn-theme border btn-sm">Tiếp tục</button>
                                </div>
                            
                        </form>
        
                    </div>
                    @else
        
        
                    <div class="row">
                        <div class="col-lg-6 mb-md--40">
                            <h3 class="heading-secondary mb-5">Thanh toán</h3>
                            <div class="login-reg-box bg-white">
                                <form action="{{route('client.services.verify-payment')}}" method="post" enctype="multipart/form-data">
                                    <div class="ps-form__content">
                                        @csrf
                                        <input type="hidden" name="transaction_type" value="{{$transaction_type}}">
                                        <input type="hidden" name="user_service_id" value="{{session('user_service_id')}}">
                                        <div class="form-group">
                                            <label class="form__label" for="user_service_id">
                                                Mã dịch vụ <span>*</span>
                                            </label>
                                            <input type="text" name="order_id" class="form-control" value="{{session('user_service_id')}}" placeholder="Mã dịch vụ" readonly>
                                        </div>
                                        @if ($error = $errors->first('user_service_id'))
                                            <div class="alert alert-danger text-center">
                                                {{$error}}
                                            </div>
                                        @endif
                                        
                                        <div class="form-group">
                                            <label for="billing_transaction_image" class="form__label">Biên lai <span>*</span></label>
                                            <div class="custom-file" style="height: 4.6rem;">
                                                <input type="file" name="image" id="billing_transaction_image" class="custom-file-input">
                                                <label class="custom-file-label" for="billing_transaction_image">Chưa có file nào dc chọn</label>
                                            </div>
                                            @if ($errors->has('image'))
                                                <div class="error has-error">{{$errors->first('image')}}</div>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                            <label for="orderNotes" class="form__label">Ghi chú </label>
                                            <textarea class="form-control" id="orderNotes" name="note" placeholder="Ghi chú (Tùy chọn)">{{old('note')}}</textarea>
                                        </div>
                                        <div class="form-group submit">
                                            <button type="submit" class="btn action_btn thm_btn">Gửi</button>
                                        </div>
                                        
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-md--40">
                            <h3 class="heading-secondary mb-5">Hướng dẫn</h3>
                            <div class=" bg-white">
                                @include($_lib.'service-payment')
                            </div>
                        </div>
                    </div>
                
                
                
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        function customFileChoose (){
        $(".custom-file-input").off();
        $(document).on("change", ".custom-file-input",function(){
            var t=$(this).val();
            var self = this;
            $(this).next(".custom-file-label").addClass("selected").html(t);

            var onc = $(self).data('on-change');
            var files = this.files;
            var callback = function (fs){
                if(!fs) fs = [];
                if(onc){
                    let oncbs = onc.split(',');
                    if(oncbs.length>1){
                        oncbs.forEach(element => {
                            let func = element.trim();
                            if(App.func.check(func)){
                                App.func.call(func, [self, fs]);
                            }
                        });
                        
                    }
                    else if(App.func.check(onc)){
                        App.func.call(onc, [self, fs]);
                    }
                
                }
            };
            if (window.File && window.FileList && files && files.length) {
                var list = [];
                var lsName  = [];
                let max = files.length - 1;
                for (var i = 0; i < files.length; i++) {
                    let file = files[i];
                    lsName.push(file.name);
                    if(onc && window.FileReader){
                        (function(file, index, coumt) {
                            let fileReader = new FileReader();
                            fileReader.onload = function(f) {
                                let src = f.target.result;
                                let data = {
                                    filename: file.name,
                                    size: file.size,
                                    data: src    
                                };
                                
                                list.push(data);
                                if(index == coumt){
                                    callback(list);
                                }
                            };
                            fileReader.readAsDataURL(file);
                        })(file, i, max);
                    }
                    if(i == max){
                        $(self).next(".custom-file-label").addClass("selected").html(lsName.join(', '));
                    }
                    
                }
            }else{
                callback([]);
            }
        });
    }
    customFileChoose();
    </script>
@endsection

@section('css3')
    <style>
        .custom-file-input.is-valid~.custom-file-label,
        .was-validated .custom-file-input:valid~.custom-file-label{
            border-color:#28a745;
        }
        .custom-file-input.is-valid~.custom-file-label::after,
        .was-validated .custom-file-input:valid~.custom-file-label::after{
            border-color:inherit;
        }
        .custom-file-input.is-valid~.valid-feedback,
        .custom-file-input.is-valid~.valid-tooltip,
        .was-validated .custom-file-input:valid~.valid-feedback,
        .was-validated .custom-file-input:valid~.valid-tooltip{display:block;}
        .custom-file-input.is-valid:focus~.custom-file-label,
        .was-validated .custom-file-input:valid:focus~.custom-file-label{
            box-shadow:0 0 0 .2rem rgba(40,167,69,.25);
        }
        .custom-file-input.is-invalid~.custom-file-label,.was-validated .custom-file-input:invalid~.custom-file-label{border-color:#dc3545}
        .custom-file-input.is-invalid~.custom-file-label::after,.was-validated .custom-file-input:invalid~.custom-file-label::after{border-color:inherit}
        .custom-file-input.is-invalid~.invalid-feedback,.custom-file-input.is-invalid~.invalid-tooltip,.was-validated .custom-file-input:invalid~.invalid-feedback,.was-validated .custom-file-input:invalid~.invalid-tooltip{display:block}
        .custom-file-input.is-invalid:focus~.custom-file-label,.was-validated .custom-file-input:invalid:focus~.custom-file-label{box-shadow:0 0 0 .2rem rgba(220,53,69,.25)}

        .input-group>.custom-file,.input-group>.custom-select,
        .input-group>.form-control{position:relative;-ms-flex:1 1 auto;flex:1 1 auto;width:1%;margin-bottom:0}
        .input-group>.custom-file+.custom-file,
        .input-group>.custom-file+.custom-select,
        .input-group>.custom-file+.form-control,
        .input-group>.custom-select+.custom-file,
        .input-group>.custom-select+.custom-select,
        .input-group>.custom-select+.form-control,
        .input-group>.form-control+.custom-file,
        .input-group>.form-control+.custom-select,
        .input-group>.form-control+.form-control{margin-left:-1px}
        .input-group>.custom-file .custom-file-input:focus~.custom-file-label,
        .input-group>.custom-select:focus,
        .input-group>.form-control:focus{z-index:3}
        .input-group>.custom-file .custom-file-input:focus{z-index:4}
        .input-group>.custom-select:not(:last-child),
        .input-group>.form-control:not(:last-child){border-top-right-radius:0;border-bottom-right-radius:0}
        .input-group>.custom-select:not(:first-child),
        .input-group>.form-control:not(:first-child){border-top-left-radius:0;border-bottom-left-radius:0}
        .input-group>.custom-file{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center}
        .input-group>.custom-file:not(:last-child) .custom-file-label,
        .input-group>.custom-file:not(:last-child) .custom-file-label::after{border-top-right-radius:0;border-bottom-right-radius:0}
        .input-group>.custom-file:not(:first-child) .custom-file-label{border-top-left-radius:0;border-bottom-left-radius:0}
        .custom-file{position:relative;display:inline-block;width:100%;height:calc(2.25rem + 2px);margin-bottom:0}
        .custom-file-input{position:relative;z-index:2;width:100%;height:calc(2.25rem + 2px);margin:0;opacity:0}
        .custom-file-input:focus~.custom-file-label{border-color:#80bdff;box-shadow:0 0 0 .2rem rgba(0,123,255,.25)}
        .custom-file-input:focus~.custom-file-label::after{border-color:#80bdff}
        .custom-file-input:disabled~.custom-file-label{background-color:#e9ecef}
        .custom-file-input:lang(en)~.custom-file-label::after{content:"Browse"}
        .custom-file-label{position:absolute;top:0;right:0;left:0;z-index:1;height:calc(2.25rem + 2px);padding:.375rem .75rem;line-height:1.5;color:#495057;background-color:#fff;border:1px solid #ced4da;border-radius:.25rem}
        .custom-file-label::after{position:absolute;top:0;right:0;bottom:0;z-index:3;display:block;height:2.25rem;padding:.375rem .75rem;line-height:1.5;color:#495057;content:"Browse";background-color:#e9ecef;border-left:1px solid #ced4da;border-radius:0 .25rem .25rem 0}
        .custom-file-label,.custom-select{transition:background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}
        @media screen and (prefers-reduced-motion:reduce){
            .custom-control-label::before,.custom-file-label,.custom-select{transition:none}
        }
        .custom-file .custom-file-input,
        .custom-file .custom-file-label,
        .custom-file .custom-file-label:after{
            height:50px;font-size:14px;padding:0 20px;line-height:48px;
        }
    </style>
@endsection
