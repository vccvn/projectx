@php
$serviceSettings = $options->theme->services;
@endphp
@php
$settings = get_account_setting_configs();
$form = $helper->getServiceForm();
@endphp
@extends($_layout.'services',[
'page_title' => "Dịch vụ của tôi",
'show_breadcrumb' => 1,
// 'breadcrumb_type' => 2
])
@section('title', 'Dịch vụ của tôi')
@include($_lib.'register-meta')

@section('content')


    <section class="doc_categories_guide_area sec_pad biz-bg-2">
        <img class="shap wow fadeInUp" src="{{ theme_asset('img/home_one/dow_bg_two.png') }}" alt="">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 order-2 order-lg-1">

                    @include($_template.'panel')
                </div>
                <div class="col-lg-9 order-2 order-lg-1">
                    @if (count($userServices))
                        <div class="row">


                            @foreach ($userServices as $userService)
                                @php
                                    $userService->applyMeta();
                                    $subdomain = $userService->subdomain . '.' . $userService->domain;
                                    $domain = $userService->alias_domain ? $userService->alias_domain : $subdomain;
                                    $url = 'http://' . $domain;
                                    if ($userService->service->web_type == 'wordpress') {
                                        $admin = 'https://wp.' . $userService->domain . '/';
                                    } elseif ($userService->service->web_type == 'vcchosting') {
                                        $admin = 'https://cpanel.' . $userService->domain . '/';
                                    } else {
                                        $admin = 'http://' . $subdomain . '/admin';
                                    }
                                    
                                @endphp
                                <div class="col-md-6">
                                    <div class="blog_grid_post wow fadeInUp">

                                        <div class="grid_post_content">
                                            <div class="post_tag">
                                                <a class="green" href="{{ $url }}">#{{ $userService->id }}</a>
                                                <a href="{{ $url }}">{{ $userService->service ? $userService->service->name : '' }}</a>

                                            </div>
                                            <a target="_blank" href="{{ $url }}">
                                                <h4 class="b_title">{{ $domain }}</h4>
                                            </a>
                                            <p>
                                                Gói: {{ $userService->package ? $userService->package->package_name : '' }}
                                            </p>
                                            <p>
                                                Ngày hết hạn: {{ $userService->expired_at }}
                                            </p>
                                            @if (!$userService->status)
                                                <p>
                                                    T.T. Thanh toán:
                                                    @if ($userService->transaction)
                                                        @if (!$userService->paid || $userService->transaction->status == 0 || $userService->transaction->status == -1)
                                                            {{ $userService->transaction->status == 0 ? 'Đang chờ duyệt' : 'Bị hủy' }}
                                                        @else
                                                            Chờ gia hạn
                                                        @endif
                                                    @else
                                                        Chưa thanh toán
                                                    @endif


                                                </p>
                                                @if (!$userService->paid)
                                                    <a href="{{ route('client.services.check-payment', ['user_service_id' => $userService->id, 'transaction_type' => 'payment']) }}" class="btn action_btn thm_btn">Thanh toán</a>
                                                @else
                                                    <a href="{{ route('client.services.check-payment', ['user_service_id' => $userService->id, 'transaction_type' => 'extension']) }}" class="btn action_btn thm_btn">Gia hạn</a>
                                                @endif

                                            @else
                                                <a target="_blank" href="{{ $admin }}" class="btn action_btn thm_btn">Quản trị</a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        {{ $userServices->links($_template . 'pagination') }}
                    @else
                        <div class="alert alert-warning text-center">
                            Hiện bạn chưa có dịch vụ nào!
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>

@endsection
