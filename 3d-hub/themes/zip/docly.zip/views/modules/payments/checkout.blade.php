@php
$settings = get_account_setting_configs();
// $form = $helper->getServiceForm();
@endphp
@extends($_layout.'services',[
'page_title' => "Thanh toán dịch vụ",
'show_breadcrumb' => 1,
// 'breadcrumb_type' => 2
])
@section('title', 'Thanh toán dịch vụ')
@include($_lib.'register-meta')
@section('content')
    <div class="contact_area sec_pad ">
        <div class="container">
            <div class="form-section">
                <div class="ps-section__content">
                    @if (!session('user_service_id'))
                        <div class="row">
                            <div class="col-md-6 ml-auto mr-auto">
                                <div class="ps-form--order-tracking bg-white">
                                    <form class="form crazy-form" action="{{ route('client.services.check-payment') }}" method="POST">
                                        @csrf
                                        @if ($error = session('error'))
                                            <div class="alert alert-danger text-center">
                                                {{ $error }}
                                            </div>
                                        @endif

                                        <div class="form-group">
                                            <label class="form__label" for="user_service_id">
                                                Mã dịch vụ <span>*</span>
                                            </label>
                                            <input type="text" name="user_service_id" class="form-control" value="{{ old('user_service_id') }}" placeholder="Mã dịch vụ">
                                        </div>
                                        @if ($error = $errors->first('user_service_id'))
                                            <div class="alert alert-danger text-center">
                                                {{ $error }}
                                            </div>
                                        @endif
                                        <div class="form-group submit">
                                            <button type="submit" class="btn btn-theme border btn-sm btn action_btn thm_btn">Tiếp tục</button>
                                        </div>

                                    </form>

                                </div>
                            </div>
                        </div>
                    @else

                        @php
                            $service = $userService->service;
                            
                        @endphp
                        <div class="row">
                            <div class="col-lg-6 mb-md--40">
                                <h3 class="heading-secondary mb-5">Hoá đơn</h3>
                                <div class="login-reg-box bg-white">

                                    <div class="table-responsive">
                                        <table class="table table-borfered">
                                            <thead></thead>
                                            <tbody>
                                                <tr>
                                                    <td class="w-200">Mã đơn hàng</td>
                                                    <td>{{ session('user_service_id') }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="w-200">Dịch vụ</td>
                                                    <td>{{ $service->name }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="w-200">Gói</td>
                                                    <td>{{ $package->package_name }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="w-200">Giá dịch vụ</td>
                                                    <td class="price-amount">{{ get_currency_format($package->price) }}</td>
                                                </tr>

                                                @if ($package->cycle_unit != 'forever')
                                                    @php
                                                        $a = $package->maintenance_fee > 0 && $package->need_fee_after_number > 0 && $package->need_fee_after_unit != 'never';
                                                        $b = [
                                                            'day' => 'ngày',
                                                            'month' => 'tháng',
                                                            'year' => 'năm',
                                                            'never' => 'khong bao giờ',
                                                        ];
                                                    @endphp
                                                    <tr>
                                                        <td class="w-200">Phí duy trì
                                                            {{ $a ? ' sau ' . $package->need_fee_after_number . ' ' . $b[$package->need_fee_after_unit] : ' từ ' . $b[$package->cycle_unit] . ' Thứ 2' }}
                                                        </td>
                                                        <td>{{ get_currency_format($package->maintenance_fee) }} / {{ $package->cycle_unit == 'year' ? 'năm' : 'tháng' }}</td>
                                                    </tr>
                                                @endif

                                                @if ($transaction_type != 'extension')

                                                    <tr>
                                                        <td class="w-200">
                                                            <label class="form__label" for="promo_code">
                                                                Mã khuyến mãi
                                                            </label>
                                                        </td>
                                                        <td>
                                                            {{ $promo_label }}
                                                            {{-- @if ($promo_code)
                                                                
                                                            @else
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" name="promo_code" class="form-control" value="{{ old('promo_code', $promo_code) }}" placeholder="Mã Khuyến mãi">
                                                                        <div class="input-group-append">
                                                                            <button type="button" class="btn btn-theme border btn-sm">Áp dụngc</button>
                                                                        </div>
                                                                    </div>


                                                                </div>
                                                            @endif --}}

                                                        </td>
                                                    </tr>

                                                @endif

                                                <tr>
                                                    <td class="w-200">Tổng thanh toán</td>
                                                    <td class="amount-total">{{ get_currency_format($transaction_type == 'extension' ? $package->maintenance_fee : $final_price) }}</td>
                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-6 mb-md--40">
                                <h3 class="heading-secondary mb-5">Phương thức thanh toán</h3>
                                <div class=" bg-white">
                                    <form action="{{ route('client.services.payment') }}" method="post" class="crazy-form">
                                        @csrf
                                        @include($_lib.'payment-methods')

                                        <button type="submit" class="btn action_btn thm_btn">Thanh toán</button>
                                    </form>
                                </div>
                            </div>
                        </div>



                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script type="text/javascript">
        var promoErrors = [
            "Thành công", // 0
            "Bạn chưa nhập mã khuyến mãi", // 1
            "Mã khuyến mãi không dược kích hoạt", // 2
            "Gói không hợp lệ",
            'Mã khuyến mãi không hợp lệ', // 3
            "Mã khuyến mãi chưa có sẵn tại thời điểm này", // 4
            "Mã khuyến mãi đã hết hiệu lực", // 5
            "Mã khuyến mãi đã dược áp dụng hết", // 6
            "Mã khuyến mãi không dược áp dụng cho dịch vụ này", // 7
            "Mã khuyến mãi không dược áp dụng cho Gói này", // 8
        ];
        var package_price = {{ $package_price }};
        var final_price = {{ $package_price }};


        function checkPromoCode() {
            var service_id = {{ $package ? $package->service_id : 0 }};
            var package_id = {{ $package ? $package->id : 0 }};
            var promo_code = $('#promo_code').val();
            var token = $('#service-package-form input[name="_token"]').val();
            if (!promo_code) return false;
            var url = "{{ route('client.services.promos.check-code') }}";
            var data = {
                service_id: service_id,
                package_id: package_id,
                promo_code: promo_code
            };
            var headers = {
                'X-CSRF-TOKEN': token
            }
            $('.amount-total').html($('.price-amount').html());

            // $('.promo-code-group .text-danger').html('');
            App.api.post(url, data, headers)
                .then(function(rs) {
                    if (rs.status) {
                        $('.amount-total').html(App.number.currency(rs.price) + "VNĐ");
                    } else {
                        App.Swal.error(promoErrors[rs.error]);
                    }
                })
                .catch(function(error) {
                    console.log(error);
                })

        }
    </script>
@endsection
