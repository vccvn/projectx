@php
    $settings = get_account_setting_configs();
    // $form = $helper->getServiceForm();
@endphp
@extends($_layout.'services',[
    'page_title' => "Thanh toán dịch vụ", 
    'show_breadcrumb' =>  1,
    // 'breadcrumb_type' => 2
])
@section('title', "Thanh toán dịch vụ")
@include($_lib.'register-meta')
@section('content')
    <div class="contact_area sec_pad ">
        <div class="container">
            <div class="form-section">
                <div class="ps-section__content">
                    @if (!session('user_service_id'))
                    <div class="ps-form--order-tracking bg-white">
                        <form class="form" action="{{route('client.services.check-payment')}}" method="POST">
                                @csrf
                                @if ($error = session('error'))
                                    <div class="alert alert-danger text-center">
                                        {{$error}}
                                    </div>
                                @endif
                
                                <div class="form-group">
                                    <label class="form__label" for="user_service_id">
                                        Mã dịch vụ <span>*</span>
                                    </label>
                                    <input type="text" name="user_service_id" class="form-control" value="{{old('user_service_id')}}" placeholder="Mã dịch vụ">
                                </div>
                                @if ($error = $errors->first('user_service_id'))
                                    <div class="alert alert-danger text-center">
                                        {{$error}}
                                    </div>
                                @endif
                                <div class="form-group submit">
                                    <button type="submit" class="btn btn-theme border btn-sm">Tiếp tục</button>
                                </div>
                            
                        </form>
        
                    </div>
                    @else
        
                    @php
                        $service = $userService->service;
                        $package = $userService->package;
                        
                    @endphp
                    <div class="row">
                        <div class="col-lg-6 mb-md--40">
                            <h3 class="heading-secondary mb-5">Hoá đơn</h3>
                            <div class="login-reg-box bg-white">

                                <div class="table-responsive">
                                    <table class="table table-borfered">
                                        <thead></thead>
                                        <tbody>
                                            <tr>
                                                <td class="w-200">Mã đơn hàng</td>
                                                <td>{{session('user_service_id')}}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-200">Dịch vụ</td>
                                                <td>{{$service->name}}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-200">Gói</td>
                                                <td>{{$package->package_name}}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-200">Giá dịch vụ</td>
                                                <td>{{get_currency_format($package->price)}}</td>
                                            </tr>

                                            @if ($package->cycle_unit != 'forever')
                                                
                                            <tr>
                                                <td class="w-200">Phí duy trì</td>
                                                <td>{{get_currency_format($package->maintenance_fee)}} / {{$package->cycle_unit == 'year' ? 'năm' : 'tháng'}}</td>
                                            </tr>
                                            @endif

                                            <tr>
                                                <td class="w-200">Tổng thanh toán</td>
                                                <td>{{get_currency_format($transaction_type == 'extension'?$package->maintenance_fee:$package->price)}}</td>
                                            </tr>

                                            
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-6 mb-md--40">
                            <h3 class="heading-secondary mb-5">Phương thức thanh toán</h3>
                            <div class=" bg-white">
                                @include($_lib.'payment-methods')
                            </div>
                        </div>
                    </div>
                
                
                
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
