@php
    $header = $options->theme->header;
    $forms = $options->theme->auth;
    $args = [];
    if($request->next){
        $args['next'] = $request->next;
    }
@endphp
@extends($_layout.'form')
@section('title', 'Đăng ký tài khoản')
{{-- @section('page_type', 'my-account') --}}
@section('css')


@endsection
@section('content')

                    <h3>{{$forms->register_title}}</h3>
                    <p>{!!$forms->register_description!!}</p>
                    <div class="page-links">
                        <a href="{{route('client.account.login', $args)}}">Đăng nhập</a><a href="{{route('client.account.register', $args)}}" class="active">Đăng ký</a>
                    </div>
                    <form class="{{parse_classname('form')}}" action="{{route('client.account.post-register')}}" method="POST">
                        @if ($next = old('next', $request->next))
                            <input type="hidden" name="next" value="{{$next}}">
                        @endif
                        @php
                            $request = request();
                            $form = $html->getRegisterForm([
                                'class' => 'form-control'
                            ]);
                        @endphp
                        @csrf
                        
                        
                        @if ($form && $inputs = $form->inputs())
                            @foreach ($inputs as $input)
                            @if ($input->name == 'agree')
                                @continue
                            @endif
                                @php
                                    if($a = $request->get($input->name)){
                                        if(!$input->value && !old($input->name))  $input->value = $a;
                                    }
                                @endphp
                                {!! $input !!}
                                @if ($input->error)
                                    <div class="has-error error text-danger">{{$input->error}}</div>
                                @endif
                            @endforeach
                        @endif
                        <input type="checkbox" name="agree" id="agree" required><label for="agree">Tôi đồng ý với <a href="{{$forms->register_terms_link('#')}}">Các điều khoản</a> của {{$siteinfo->site_name('Web 1-0-2')}}</label>

                        <div class="form-button">
                            <button id="submit" type="submit" class="ibtn">Đăng ký</button>
                        </div>
                    </form>
                    <div class="other-links">
                        <span>Hoặc sử dụng tài khoản</span>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-google"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
@endsection
