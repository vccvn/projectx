@extends($_layout.'form')
@section('title', 'Đặt lại mật khảu')
{{-- @section('page_type', 'my-account') --}}
@section('css')

@endsection
@section('content')
                    <h3>Đặt lại mật khẩu</h3>
                    <p>Nhập email để lấy link đặt lại mật khẩu</p>
                    
                    @if ($error = session('error'))
                        
                    <div class="alert alert-warning alert-dismissible fade show with-icon" role="alert">
                        {{$error}}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    <form class="{{parse_classname('form')}}" action="{{route('client.account.post-forgot')}}" method="POST">
                        
                        @csrf

                        <input class="form-control" type="email" name="email" value="{{old('email')}}" placeholder="Nhập email">
                            @if ($error = $errors->first('email'))
                                <div class="has-error error text-danger">{{$error}}</div>
                            @endif
                        <div class="form-button full-width">
                            <button id="submit" type="submit" class="ibtn">Nhận link đặt lại mật khâu</button>
                        </div>
                    </form>
                    <div class="form-sent">
                        <div class="tick-holder">
                            <div class="tick-icon"></div>
                        </div>
                        <h3>Password link sent</h3>
                        <p>Please check your inbox <a href="http://brandio.io/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="6801070e1a052801070e1a051c0d051804091c0d460107">[email&#160;protected]</a></p>
                        <div class="info-holder">
                            <span>Unsure if that email address was correct?</span> <a href="#">We can help</a>.
                        </div>
                    </div>
                    
                    <div class="other-links">
                        <span>Hoặc</span>
                        <a href="{{route('client.account.login')}}">Đăng nhập</a>
                        <a href="{{route('client.account.register')}}">Đăng ký</a>
                        
                    </div>
@endsection
