@extends($_layout.'form')
@section('title', 'Xác minh tài khoản')
{{-- @section('page_type', 'my-account') --}}
@section('css')

@endsection
@section('content')
    <h3>Xác minh tài khoản</h3>
    <p>Nhập email để lấy link xác minh tài khoản</p>
    
    @if ($error = session('error'))
        
    <div class="alert alert-warning alert-dismissible fade show with-icon" role="alert">
        {{$error}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    <form class="{{parse_classname('form')}}" action="{{route('client.account.verify.send-email')}}" method="POST">
        
        @csrf

        <input class="form-control" type="email" name="email" value="{{old('email')}}" placeholder="Địa chỉ email">
            @if ($error = $errors->first('email'))
                <div class="has-error error text-danger">{{$error}}</div>
            @endif
        <div class="form-button full-width">
            <button id="submit" type="submit" class="ibtn">Xác minh</button>
        </div>
    </form>
@endsection
