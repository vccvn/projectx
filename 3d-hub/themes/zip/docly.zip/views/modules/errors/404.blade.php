@extends($_layout.'clean')

@section('title', '404 - Không tìm thấy')
    
@section('meta.robots', 'noindex,nofollow')
@section('content')
<section class="error_area bg_color">
    <div class="error_dot one"></div>
    <div class="error_dot two"></div>
    <div class="error_dot three"></div>
    <div class="error_dot four"></div>
    <div class="container">
        <div class="error_content_two text-center">
            <div class="error_img">
                <img class="p_absolute error_shap" src="{{theme_asset('img/404_bg.png')}}" alt="">
                <div class="one wow clipInDown" data-wow-delay="1s"><img class="img_one" src="{{theme_asset('img/404_two.png')}}" alt=""></div>
                <div class="two wow clipInDown" data-wow-delay="1.5s"><img class="img_two" src="{{theme_asset('img/404_three.png')}}" alt=""></div>
                <div class="three wow clipInDown" data-wow-delay="1.8s"><img class="img_three" src="{{theme_asset('img/404_one.png')}}" alt=""></div>
            </div>
            <h2>Opps! Trang bạn đang truy cập hiện không được tìm thấy</h2>
            <p>Xin lỗi vì sự bất tiện này bạn có thể quay về trang chủ để kiểm tra lại học sử dụng công cụ tìm kiếm...</p>
            <form action="{{route('client.search')}}" class="error_search">
                <input type="text" name="s" class="form-control" placeholder="Tìm kiếm">
            </form>
            <a href="{{route('home')}}" class="action_btn box_shadow_none"><i class="arrow_left"></i>Vè trang chủ</a>
        </div>
    </div>
</section>
@endsection