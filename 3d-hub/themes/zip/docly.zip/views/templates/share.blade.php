
<?php 
$url = urlencode(isset($link)?$link:route('home'));
$desc = urlencode(isset($description)?$description:'');
$img = urlencode(isset($image)?$image:'');
$tit = urlencode(isset($title)?$title:'');
?>
<div class="blog_social text-center">
    <h5>{{isset($share_title)?$share_title:'Chia sẻ'}}</h5>
    <ul class="list-unstyled f_social_icon">
        <li><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u={{$url}}&amp;src=sdkpreparse"><i class="social_facebook"></i></a></li>
        <li><a target="_blank" href="https://twitter.com/intent/tweet?text={{$url}}{{$desc?' '.$desc:''}}"><i class="social_twitter"></i></a></li>
        <li><a target="_blank" href="http://pinterest.com/pin/create/button/?url={{$url}}{{isset($desc)?'&description='.$desc:''}}"><i class="social_pinterest"></i></a></li>
        <li><a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url={{$url}}&title={{$tit}}&summary={{$desc}}&source="><i class="social_linkedin"></i></a></li>
    </ul>
</div>