@php
    $active_type = isset($active_type)?$active_type:null;
@endphp
<div class="row">
    @if ($service->packages && count($service->packages))
        @foreach ($service->packages as $package)
            <div class="col-md-4">
                <div class="card card-pricing card-{{$package->account_type == $active_type?'raised': 'plain'}}">
                    <div class="card-content">
                        <h6 class="category">{{$package->package_name}}</h6>
                        <h3 class="card-title">{{number_format($package->price, 0, ',', '.')}}<small>Đ</small></h3>
                        <ul>
                            {!! 
                                implode('', array_map(function($line){
                                    return '<li>'
                                        . str_replace(
                                            ['[t]', '[T]', '[check]', '[v]'],
                                            '<i class="fas fa-check"></i>',

                                            str_replace(
                                                ['[f]', '[F]', '[times]', '[x]'],
                                                '<i class="fas fa-times"></i>',
                                                $line
                                            )
                                        )
                                    .'</li>';
                                }, nl2array($package->features)))
                            !!}
                        </ul>
                        <div class="buy-btn">
                            <a href="{{
                                route('client.services.add', [
                                    'service_id' => $service->id, 
                                    'package_id' => $package->id
                                ])
                                }}" class="biz-btn-{{$package->account_type == $active_type?'solid': 'outline'}}">
                                Đăng ký
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    @endif
</div>