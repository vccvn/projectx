<nav class="navbar navbar-expand-lg menu_one display_none nav-style-{{$headerStyle}}" id="stickyTwo">
    <div class="container-fluid pl-60 pr-60">
        <a class="navbar-brand" href="{{route('home')}}">
            {{-- <img src="{{$lg1 = $header->logo_light($header->logo($siteinfo->logo(theme_asset('img/logo-w.png'))))}}" srcset="{{$lg1}} 2x" alt="{{$siteinfo->site_name}}"> --}}
            <img src="{{$lg2 = $header->logo($siteinfo->logo(theme_asset('img/logo.png')))}}" srcset="{{$lg2}} 2x" alt="{{$siteinfo->site_name}}">
            <img src="{{$lg2}}" srcset="{{$lg2}} 2x" alt="{{$siteinfo->site_name}}">
        </a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu_toggle">
                <span class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
                <span class="hamburger-cross">
                    <span></span>
                    <span></span>
                </span>
            </span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            {!!
                dockly_menu_primary([
                    'class' => 'navbar-nav menu ml-auto'
                ])
            !!}
            <ul class="list-unstyled menu_social">
                <li class="search">
                    <form action="{{isset($dynamic)?$dynamic->getViewUrl():route('client.search')}}" method="get" class="search_form">
                        <input type="search" name="s" class="form-control" placeholder="Tìm kiếm" value="{{$request->s}}">
                        <button type="submit"><i class="icon_search"></i></button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>