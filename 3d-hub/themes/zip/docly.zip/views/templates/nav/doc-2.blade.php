<nav class="navbar navbar-expand-lg menu_two nav-style-{{$headerStyle}}" id="sticky">
    <div class="container">
        <a class="navbar-brand" href="{{route('home')}}">
            <img src="{{$lg = $header->logo($siteinfo->logo(theme_asset('img/logo.png')))}}" srcset="{{$lg}} 2x" alt="{{$siteinfo->site_name}}">
            <img src="{{$lg}}" srcset="{{$lg}} 2x" alt="{{$siteinfo->site_name}}">
        </a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu_toggle">
                <span class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
                <span class="hamburger-cross">
                    <span></span>
                    <span></span>
                </span>
            </span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            {!!
                dockly_menu_primary([
                    'class' => 'navbar-nav menu dk_menu ml-auto'
                ])
            !!}
            @if ($header->nav_2_show_button)
                <a class="nav_btn" href="{{$header->nav_2_button_url}}">{{$header->nav_2_button_text}}</a>
            @endif
            
        </div>
    </div>
</nav>