
<div class="categories_guide_item wow fadeInUp">
    <div class="doc_tag_title">
        <h4>Tài khoản</h4>
    </div>
    <ul class="list-unstyled tag_list">
        @foreach ($settings as $sk => $item)
            <li><a class="" href="{{route('client.account.settings', ['tab' => $item->slug])}}">{{$item->title}}</a></li>
        @endforeach
        <li><a href="{{route('client.services.list')}}">Dịch vụ</a></li>
        <li><a href="{{route('client.services.add')}}">Thêm dịch vụ</a></li>
        
        <li><a href="{{route('client.account.logout')}}">Thoát</a></li>
    </ul>
    {{-- <a href="#" class="doc_border_btn">More<i class="arrow_right"></i></a> --}}
</div>