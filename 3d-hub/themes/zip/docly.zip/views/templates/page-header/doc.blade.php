
<section class="breadcrumb_area">
    <img class="p_absolute bl_left" src="{{theme_asset('img/v.svg')}}" alt="">
    <img class="p_absolute bl_right" src="{{theme_asset('img/home_one/b_leaf.svg')}}" alt="">
    <img class="p_absolute star" src="{{theme_asset('img/home_one/banner_bg.png')}}" alt="">
    <img class="p_absolute wave_shap_one" src="{{theme_asset('img/blog-classic/shap_01.png')}}" alt="">
    <img class="p_absolute wave_shap_two" src="{{theme_asset('img/blog-classic/shap_02.png')}}" alt="">
    <img class="p_absolute one wow fadeInRight" src="{{theme_asset('img/home_one/b_man_two.png')}}" alt="">
    <img class="p_absolute two wow fadeInUp" data-wow-delay="0.2s" src="{{theme_asset('img/home_one/flower.png')}}" alt="">
    <div class="container custom_container">
        <form action="{{$dynamic->getViewUrl()}}" class="banner_search_form banner_search_form_two">
            <div class="input-group">
                <input type="search" class="form-control" name="s" placeholder="Tìm kiếm" value="{{$request->s}}">
                <div class="input-group-append">
                    {!!
                        html_input([
                            'type' => 'select',
                            'name' => 'category_id',
                            'id' => 'inlineFormCustomSelect',
                            'class' => 'custom-select',
                            'data' => get_post_cate_options(['dynamic_id' => $dynamic->id],'Tất cả'),
                            'default' => $request->category_id
                        ])
                    !!}
                </div>
                <button type="submit"><i class="icon_search"></i></button>
            </div>
        </form>
    </div>
</section>