@php
    $pageHeader = $postSettings->makeByPrefix('header_');
    if($bg = $__env->yieldContent('page_header_bg_image')){
        $pageHeader->bg_image = $bg;
        $pageHeader->use_bg_image = 1;
        
    }
    $attr = docly_attrs($pageHeader, [
        'class' => 'breadcrumb_area_two'
    ]);
@endphp
        <section {!!$attr!!}>
            <div class="container">
                <div class="breadcrumb_content">
                    <h2>@yield('page_title', isset($page_title)?$page_title:'')</h2>
                    @if (($p = get_active_model('post')) && !$postSettings->detail_hide_meta)
                        @php
                            $author = $p->author;
                        @endphp
                        <div class="single_post_author">
                            @if ($author)
                                <img class="author_img" src="{{$author->getAvatar()}}" alt="{{$author->name}}">
                            @endif
                            
                            <div class="text">
                                @if ($author)
                                    <a href="#"><h4>{{$author->name}}</h4></a>
                                @endif
                                    
                                <div class="post_tag">
                                    
                                        <a href="#">{{$p->timeAgo()}}</a>
                                        @if ($p->category)
                                        <a class="c_blue" href="{{$p->category->getViewUrl()}}">{{$p->category->name}}</a>    
                                        @elseif(count($p->tags))
                                            @foreach ($p->tags as $tag)
                                                @if ($loop->index < 2)
                                                    <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                                @endif
                                            @endforeach
                                        @endif
                                    
                                </div>
                            </div>
                        </div>
                        
                    @endif
                </div>
            </div>
        </section>