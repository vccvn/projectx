@php
$footer = $options->theme->footer;
@endphp
<footer class="footer_area f_bg_color">
    <img class="p_absolute leaf" src="{{theme_asset('img/v.svg')}}" alt="">
    <img class="p_absolute f_man" src="{{theme_asset('img/home_two/f_man.png')}}" alt="">
    <img class="p_absolute f_cloud" src="{{theme_asset('img/home_two/cloud.png')}}" alt="">
    <img class="p_absolute f_email" src="{{theme_asset('img/home_two/email-icon.png')}}" alt="">
    <img class="p_absolute f_email_two" src="{{theme_asset('img/home_two/email-icon_two.png')}}" alt="">
    <img class="p_absolute f_man_two" src="{{theme_asset('img/home_two/man.png')}}" alt="">
    <div class="footer_top">
        <div class="container">
            <div class="row">
                {!! $html->docly_footer->components !!}
            </div>
            <div class="border_bottom"></div>
        </div>
    </div>
    <div class="footer_bottom text-center">
        <div class="container">
            <p>
                @if ($footer->copyright)
                    {!! $footer->copyright !!}
                @else
                    &copy; {{date('Y')}} {{$siteinfo->site_name}}. Giữ toàn quyền
                @endif
                
            </p>
        </div>
    </div>
</footer>

{!! $html->body_bottom->components !!}