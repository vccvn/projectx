<div class="blog_sidebar pl-40">
    {!! $html->sidebar_project->components !!}

</div>