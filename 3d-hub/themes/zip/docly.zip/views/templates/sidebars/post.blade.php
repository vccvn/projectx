<div class="blog_sidebar pl-40">
    {!! $html->sidebar_post->components !!}
    {{-- <div class="widget about_widget">
        <div class="img"><img src="{{theme_asset('img/blog-single/about_img.jpg')}}" alt=""></div>
        <div class="text">
            <a href="#">
                <h3>Rodney Artichoke</h3>
            </a>
            <p>James Bond jolly good happy days smashing barney bonnet bits and bobs loo.!</p>
        </div>
    </div> --}}

    {{-- <div class="widget instragram_widget">
        <h4 class="c_head">Instragram</h4>
        <div class="instragram_info">
            <a href="#" class="instragram_item">
                <img src="{{theme_asset('img/blog-single/image_01.jpg')}}" alt="">
            </a>
            <a href="#" class="instragram_item">
                <img src="{{theme_asset('img/blog-single/image_02.jpg')}}" alt="">
            </a>
        </div>
    </div> --}}

</div>