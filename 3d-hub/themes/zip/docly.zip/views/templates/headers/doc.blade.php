@php

    $lg1 = $header->logo_light($header->logo($siteinfo->logo(theme_asset('img/logo-w.png'))));
    $lg2 = $header->logo($siteinfo->logo(theme_asset('img/logo.png')));
    $lg = $header->logo($siteinfo->logo(theme_asset('img/logo.png')));

@endphp


@include($_template.'nav.doc-'.$headerStyle, ['container_class' => 'custom_container'])

<div class="mobile_main_menu" id="sticky">
    <div class="container">
        <div class="mobile_menu_left">
            <button type="button" class="navbar-toggler mobile_menu_btn">
                <span class="menu_toggle ">
                    <span class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </span>
            </button>
            <a class="sticky_logo" href="{{route('home')}}">
                @if ($headerStyle == '1')
                    <img src="{{$lg1}}" srcset="{{$lg1}} 2x" alt="{{$siteinfo->site_name}}">
                    <img src="{{$lg2}}" srcset="{{$lg2}} 2x" alt="{{$siteinfo->site_name}}">
                @else
                    <img src="{{$lg}}" srcset="{{$lg}} 2x" alt="{{$siteinfo->site_name}}">
                @endif
            </a>
        </div>
        <div class="mobile_menu_right">
            <form action="{{isset($dynamic)?$dynamic->getViewUrl():route('client.search')}}" method="get" class="search_form">
                <input type="search" name="s" class="form-control" placeholder="Tìm kiếm" value="{{$request->s}}">
                <button type="submit"><i class="icon_search"></i></button>
            </form>
        </div>
    </div>
</div>

<div class="click_capture"></div>
<div class="side_menu">
    <div class="mobile_menu_header">
        <div class="close_nav">
            <i class="arrow_left"></i>
            <i class="icon_close"></i>
        </div>
        <div class="mobile_logo">
            <a href="{{route('home')}}"><img src="{{$header->logo($siteinfo->logo(theme_asset('img/logo.png')))}}" alt="{{$siteinfo->site_name}}"></a>
        </div>
    </div>
    <div class="mobile_nav_wrapper">
        <nav class="mobile_nav_top">
            {!! dockly_mobile_menu($postSettings->mobile_menu_id('primary'),[
                'class' => 'navbar-nav menu ml-auto'
            ]) !!}

        </nav>
        <div class="mobile_nav_bottom">
            <aside class="doc_left_sidebarlist">
                <h2>{{$siteinfo->site_name}}</h2>
                <div class="scroll">
                    {!!
                        dockly_sidebar_mobile_menu($postSettings->sidebar_menu_id('docsleft'),[
                            'class' => 'list-unstyled nav-sidebar'
                        ])
                    !!}
                </div>
            </aside>
        </div>
    </div>
</div>
