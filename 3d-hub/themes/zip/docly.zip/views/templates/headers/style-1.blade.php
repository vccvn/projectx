@php
    
    $header = $options->theme->header;
    $headerStyle = isset($header_style)?$header_style:$__env->yieldContent('header_style', 
        isset($option)?$option->header_style($header->header_style(1)):$header->header_style(1)
    );

@endphp

@include($_template.'nav.style-'.$headerStyle)