<div class="breadcrumb_area_three">
    <img class="p_absolute one" src="{{theme_asset('img/typography/leaf_left.png')}}" alt="">
    <img class="p_absolute two" src="{{theme_asset('img/typography/man_01.png')}}" alt="">
    <img class="p_absolute three" src="{{theme_asset('img/typography/man_02.png')}}" alt="">
    <img class="p_absolute four" src="{{theme_asset('img/typography/leaf_right.png')}}" alt="">
    <div class="container">
        <div class="breadcrumb_text">
            <h2>@yield('page_title', isset($page_title)?$page_title:'')</h2>
            <p>@yield('page_description', isset($page_description)?$page_description:'')</p>
        </div>
    </div>
</div>