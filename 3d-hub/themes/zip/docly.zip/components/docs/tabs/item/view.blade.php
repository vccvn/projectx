

<div class="tab-pane fade {{$data->active?'show active':''}}" id="card" role="tabpanel" aria-labelledby="card-tab">
    {!! $data->content !!}
</div>