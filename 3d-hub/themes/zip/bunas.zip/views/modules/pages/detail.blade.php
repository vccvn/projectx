@php
    $title = $article->title;
    $next = $article->next();
    $previous = $article->previous();
    $url = $article->getViewUrl();
    $category = $article->getCategory();
@endphp

@extends($_layout.'master',[
    'page_title' => $title,
    'show_breadcrumb' =>  1,
    'module_class' => 'single'
])
@include($_lib.'register-meta')
@section('page_title', $title)
@section('content')







<div class="about-area default-padding">
    <div class="container">
        <div class="post-content">
            {!! $article->content !!}
        </div>
        
    </div>
</div>




@endsection