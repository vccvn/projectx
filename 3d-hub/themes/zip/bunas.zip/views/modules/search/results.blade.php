
@extends($_layout.'master')

@section('css')
    <style>
        .search-group input[type="search"]{
            min-height: 39px;
        }

    </style>
@endsection


@section('content')


    <!-- Start Breadcrumb 
        
    ============================================= -->
    <div class="breadcrumb-area shadow dark bg-fixed text-center text-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <form action="{{route('client.search')}}">
                        <div class="row">
                            <div class="col-xs-12 col-md-3 col-lg-2">
                                <h3 style="margin-bottom: 0; margin-top: 4px;">Tỉm kiếm</h3>
                            </div>
                            <div class="col-xs-12 col-md-6 col-lg-8">
                                <div class="input-group search-group">
                                    <input type="search" name="s" class="form-control" placeholder="Tìm kiếm" title="Tìm kiếm" value="{{$keywords}}" />
                                    <div class="input-group-btn">
                                        <button type="submit" class="btn bg-default btn-icon"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <ul class="breadcrumb text-center">
                        @if (count($refs = $helper->getSearchRefOptions($r = strtolower($request->ref))))                
                            @foreach ($refs as $ref => $text)
                            <li class="{{$ref == $r ? 'active': ''}}">
                                @if ($ref == $r)
                                    {{$text}}
                                @else
                                    <a href="{{route('client.search', ['ref' => $ref, 's' => $keywords])}}">{{$text}}</a>
                                @endif
                                
                            </li>
                            @endforeach
                        @endif
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->


<div class="blog-area  right-sidebar default-padding">
    <div class="container">
        <div class="row">
            <div class="blog-items">
                <div class="blog-content col-md-8">
                                        
                    @if (count($results))
                    
                        @foreach ($results as $result)
                            @if ($loop->first || $loop->index % 2 == 0)
                                
                                <div class="row">
                            @endif

                            <!-- Single Item -->
                            <div class="col-sm-6 col-5 col-xs-12 single-item">
                                <div class="item">
                                    <div class="thumb">
                                        <a href="{{$url = $result->getViewUrl()}}"><img src="{{$result->getImage('social')}}" alt="{{$result->title}}"></a>
                                        @if(count($result->tags))
                                        <div class="tags">
                                            @foreach ($result->tags as $tag)
                                                <a href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                            @endforeach
                                        </div>
                                        @endif
                                    </div>
                                    <div class="info">
                                        <div class="meta">
                                            <ul>
                                                <li>{{$result->dateFormat('d/m/Y')}}</li>
                                                {{-- @if ($result->comment_count) --}}
                                                <li><a href="{{$url}}#comments"><i class="fas fa-comments"></i> {{$result->comment_count}} Bình luận</a></li>    
                                                {{-- @endif --}}
                                                
                                            </ul>
                                        </div>
                                        <div class="title">
                                            <h4>
                                                <a href="{{$url}}">{{$result->title}} </a>
                                            </h4>
                                        </div>
                                        
                                        <p>
                                            {{$result->getShortDesc(100)}}
                                        </p>
                                        <a class="btn btn-theme border btn-sm" href="{{$url}}">Xem thêm</a>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                            @if ($loop->last || $loop->index % 2 == 1)
                                 </div>
                            @endif
                        @endforeach

                        {{$results->links($_template.'pagination')}}
                    @else
                    <div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
                    @endif

                </div>
                <!-- Start Sidebar -->
                <div class="sidebar col-md-4">
                    @include($_template.'sidebar-post')
                </div>
                <!-- End Start Sidebar -->
            </div>
        </div>
    </div>
</div>

@endsection