@extends($_layout.'master')

@section('content')
    {!! $html->home->components !!}

@endsection