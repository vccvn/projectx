@extends($_layout.'form')
@section('title', 'Tạo mật khẩu mới')
{{-- @section('page_type', 'my-account') --}}
@section('css')

@endsection
@section('content')
                    <h3>Tạo mật khẩu mới</h3>
                    <p>Hãy chọn một mật khẩu đặt biệt và khó đoán để đảm bảo an toàn</p>
                    
                    @if ($error = session('error'))
                        
                    <div class="alert alert-warning alert-dismissible fade show with-icon" role="alert">
                        {{$error}}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    <form class="{{parse_classname('form')}}" action="{{route('client.account.password.reset')}}" method="POST">
                        
                        @csrf
                        <input type="hidden" name="token" value="{{old('token', $token)}}">
                        <div class="form-group">
                            <input class="form-control" type="password" name="password" placeholder="Mật khẩu mới">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="password" name="password_confirmation" placeholder="Nhập lại mật khẩu">
                        </div>
                        
                        <div class="form-button full-width">
                            <button id="submit" type="submit" class="ibtn">Tạo mật khẩu</button>
                        </div>
                    </form>


@endsection
