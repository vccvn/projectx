@php
    $contacts = $options->theme->contacts;
    $title = $contacts->title('Liên hệ');
@endphp
@extends($_layout.'master',[
    'page_title' => $title, 
    'show_breadcrumb' =>  1
])
@include($_lib.'register-meta')
@section('title', $title)

@if ($contacts->description)
    
@section('meta_description', $contacts->description)
    
@endif
@section('content')

<div class="about-area default-padding contact-area-info">
    <div class="container">
        <p>
            {{$contacts->descrition}}
        </p>
        <div class="row">
            <div class="info box">
                <div class="col-6 col-xs-12 col-md-6">
                    
                    <div class="features">
                        <div class="item">
                            <div class="icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="info">
                                <h4>{{$contacts->phone_number}}</h4>
                            </div>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="info">
                                <h4>{{$contacts->email}}</h4>
                                
                            </div>
                        </div>

                        <div class="clearfix"></div>
                        
                    </div>
                </div>
                <div class="col-6 col-xs-12 col-md-6">
                    
                    <div class="features">
                        <div class="item">
                            <div class="icon">
                                <i class="fab fa-facebook-f"></i>
                            </div>
                            <div class="info">
                                <h4>{{$contacts->facebook('LeNgocDoan')}}</h4>
                            </div>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="info">
                                <h4>{{$contacts->address}}</h4>
                                
                            </div>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    <!-- Star Contact Area
    ============================================= -->
    <div class="contact-area" style="padding-bottom: 120px">
        <div class="container">
            <div class="row">

                <!-- Start Faq -->
                <div class="col-md-6 faq-area">
                    <div class="heading">
                        <h2>{{$contacts->faq_title("Các câu hỏi thường gặp")}}</h2>
                    </div>
                    <div class="acd-items acd-arrow">
                        <div class="panel-group symb" id="accordion">


                            {!! $html->contact_faq->components !!}
                        </div>
                    </div>
                </div>
                <!-- End Faq -->

                <!-- Start Contact Info -->
                <div class="col-md-6 contact-forms">
                    <div class="contact-box">
                        <div class="icon">
                            <i class="ti-email"></i>
                        </div>
                        <h2>{{$contacts->form_title("Nếu bạn có ý tưởng hay thắc mắc gì ")}}</h2>
                        <p>
                            {{$contacts->form_description}}
                        </p>
                        <form method="POST" action="{{route('client.contacts.send')}}" data-ajax-url="{{route('client.contacts.ajax-send')}}" class="{{parse_classname('contact-form')}} contact-form1">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group">
                                        <input class="form-control inp" id="name" name="name" placeholder="Tên" type="text" required>
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input class="form-control inp" id="email" name="email" placeholder="Email*" type="email">
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input class="form-control inp" id="phone_number" name="phone_number" placeholder="Số điễn thoại (Tùy chọn)" type="text">
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group comments">
                                        <textarea class="form-control inp" id="comments" name="message" placeholder="Hãy nói về dự án của bạn...  *"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <button type="submit" name="submit" id="submit">
                                        {{$contacts->button_text('Gửi')}} <i class="fa fa-paper-plane"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- Alert Message -->
                            <div class="col-md-12 alert-notification">
                                <div id="message" class="alert-msg"></div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- End Contact Info -->

            </div>
        </div>
    </div>
    <!-- End Contact Area -->

    <!-- Start Google Maps 
    ============================================= -->
    <div class="maps-area">
        <div class="container-full">
            <div class="row">
                <div class="google-maps">
                    {!! $contacts->map_code !!}
                </div>
            </div>
        </div>
    </div>
    <!-- End Google Maps -->

@endsection