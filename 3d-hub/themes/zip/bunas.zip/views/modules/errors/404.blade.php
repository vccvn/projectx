@extends($_layout.'master')

@section('title', '404 - Không tìm thấy')
    
@section('meta.robots', 'noindex,nofollow')
@section('content')
    
    <!-- Start 404 
    ============================================= -->
    <div class="error-page-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-5 thumb">
                    <img src="{{theme_asset('img/404.png')}}" alt="Thumb">
                </div>
                <div class="col-md-7 error-box">
                    <h1>4<span>0</span>4</h1>
                    <h2>Trang này không tồn tại</h2>
                    <p>
                        Trang bạn đang truy cập hiện không tồn tại hoặc đã bị xóa
                    </p>
                    <a class="btn btn-theme effect btn-md" href="{{route('home')}}">Trang chủ</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End 404 -->
@endsection