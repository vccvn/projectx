@php
    $title = $article->title;
    $next = $article->next();
    $previous = $article->previous();
    $url = $article->getViewUrl();
    $category = $article->getCategory();
@endphp

@extends($_layout.'sidebar',[
    'page_title' => $title,
    'show_breadcrumb' =>  1,
    'module_class' => 'single'
])
@include($_lib.'register-meta')
@section('page_title', $title)

@if ($article->service_id && $service = $helper->getService(['id' => $article->service_id, '@with' => ['packages']]))
                
    @if (count($service->packages))
        @section('css')
            <style>
                .pricing-area .pricing-item .pricing-header{
                    padding: 15px 30px;
                }
                .pricing-simple li.pricing-header span.badge {
                    right: -79px;
                    top: 3px;
                }
            </style>
        @endsection
        @section('pricing_table')
            
        <div id="pricing" class="pricing-area bg-light">
            <div class="pricing pricing-simple text-center">
                @foreach ($service->packages as $item)
                    
                <div class="col-lg-4 col-md-4 single-item ">
                    <div class="pricing-item {{$loop->index == 1 ? 'active' : ''}}">
                        <ul>
                            <li class="pricing-header">
                                <h4>{{$item->package_name}}</h4>
                                @if ($loop->index == 1)
                                <span class="badge">HOT</span>
                                @endif
                            </li>
                            {!! 
                                implode('', array_map(function($line){
                                    return '<li>'
                                        . str_replace(
                                            ['[t]', '[T]', '[check]', '[v]'],
                                            '<i class="fas fa-check"></i>',

                                            str_replace(
                                                ['[f]', '[F]', '[times]', '[x]'],
                                                '<i class="fas fa-times"></i>',
                                                $line
                                            )
                                        )
                                    .'</li>';
                                }, nl2array($item->features)))
                            !!}
                            <li class="price">
                                <h3>
                                    {{-- <sup class="fs-14">Chỉ từ</sup> --}}
                                    {{number_format($item->price, 0, ',', '.')}}
                                    <sup>Đ</sup>
                                    {{-- <sub class="fs-20">{{$item->cycle_unit}}</sub> --}}
                                    {{-- <sub>/ tháng</sub> --}}
                                </h3>
                            </li>
                            <li class="footer">
                                <a 
                                class="btn btn-theme {{$loop->index == 1 ? 'effect' : 'border'}} btn-sm" 
                                href="{{route('client.services.add',['service_id' => $item->service_id, 'package_id' => $item->id])}}"
                                >Chọn</a>
                            </li>
                        </ul>
                    </div>
                </div>
                
                @endforeach
            </div>
        </div>
        
        @endsection
    @endif
@endif


@section('content')
<div class="item">

    <!-- Start Post Thumb -->
    <div class="thumb">
        <a href="{{$url = $article->getViewUrl()}}"><img src="{{$article->getImage('800x300')}}" alt="{{$article->title}}"></a>
        
        @if ($article->category && $tree = $article->category->getTree())
            <div class="tags">
                @foreach ($tree as $cate)
                <a href="{{$cate->getViewUrl()}}">{{$cate->name}}</a>
                @endforeach                                                
            </div>
        @endif
    </div>
    <!-- Start Post Thumb -->

    <div class="info">
        <div class="meta">
            <ul>
                <li>{{$article->dateFormat('d/m/Y')}}</li>
                {{-- @if ($article->comment_count) --}}
                <li><a href="{{$url}}#comments"><i class="fas fa-comments"></i> {{$article->comment_count}} Bình luận</a></li>    
                {{-- @endif --}}
                
            </ul>
        </div>
        <div class="title">
            <h4>
                <a href="{{$url}}">{{$article->title}} </a>
            </h4>
        </div>
        <div class="post-content">
            {!! 
                str_eval($article->content, [
                    'pricing_table' => $__env->yieldContent('pricing_table')
                ])
            !!}
            
        </div>
        
        @if ($next || $previous)

        <!-- Start Post Pagination -->
        <div class="post-pagi-area">
            @if ($previous)
            <a href="{{$previous->getViewUrl()}}"><i class="fas fa-angle-double-left"></i> Trước</a>
            @else
            <a href="javascript:void(0)"></a>
            @endif

            @if ($next)
                <a href="{{$article->getViewUrl()}}">Sau <i class="fas fa-angle-double-right"></i></a>
            @else
                <a href="javascript:void(0)"></a>
            @endif
        
        </div>
        <!-- End Post Pagination -->
        @endif

        <!-- Start Post Tag s-->
        <div class="post-tags share">
            @if(count($article->tags))
                <div class="tags">
                    <span>Tags: </span>
                    @foreach ($article->tags as $tag)
                        <a href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'': ', '}}
                    @endforeach
                </div>
            @endif
        </div>
        <!-- End Post Tags -->

        @include($_template.'comments',[
            'comments' => $article->publishComments,
            'ref' => 'post',
            'ref_id' => $article->id,
            'url' => $article->getViewUrl()
        ])

    </div>
</div>
@endsection