@php
    $settings = get_account_setting_configs();
    $form = $helper->getServiceForm();
@endphp
@extends($_layout.'master',[
    'page_title' => "Dịch vụ của tôi", 
    'show_breadcrumb' =>  1,
    // 'breadcrumb_type' => 2
])
@section('title', "Dịch vụ của tôi")
@include($_lib.'register-meta')

@section('content')
    <div class="blog-area full-blog left-sidebar full-blog default-padding bg-gray ">
       <div class="container">
           <div class="row">
                <div class="blog-items">
                    <div class="sidebar col-md-4">
                        <aside>
                            @include($_template.'panel')
                        </aside>
                    </div>
                    <div class="blog-content col-md-8">
                        @if (count($userServices))
                        
                            @foreach ($userServices as $userService)
                                @php
                                    $userService->applyMeta();
                                    $subdomain = $userService->subdomain . '.' . $userService->domain;
                                    $domain = $userService->alias_domain?$userService->alias_domain:($subdomain);
                                    $url = 'http://'.$domain;
                                    $admin = 'http://'.$subdomain . '/admin';
                                @endphp
                                @if ($loop->first || $loop->index % 2 == 0)
                                    
                                    <div class="row">
                                @endif

                                <!-- Single Item -->
                                <div class="col-sm-6 col-5 col-xs-12 single-item">
                                    <div class="item">
                                        <div class="info">
                                            <div class="meta">
                                                <ul>
                                                    <li>{{$userService->service?$userService->service->name:''}}</li>
                                                    <li>#{{$userService->id}}</li>
                                                </ul>
                                            </div>
                                            <div class="title">
                                                <h4>
                                                    <a target="_blank" href="{{$url}}">{{$domain}}</a>
                                                </h4>
                                            </div>
                                            <p>
                                                Gói: {{$userService->package?$userService->package->package_name:''}} 
                                                <br>
                                                Ngày hết hạn: {{$userService->expired_at}}
                                            </p>
                                            @if (!$userService->status)
                                                @if (!$userService->paid)
                                                <a href="{{route('client.services.check-payment', ['user_service_id' => $userService->id, 'transaction_type' => 'payment'])}}" class="btn btn-theme border btn-sm">Thanh toán</a>
                                                @else
                                                <a href="{{route('client.services.check-payment', ['user_service_id' => $userService->id, 'transaction_type' => 'extension'])}}" class="btn btn-theme border btn-sm">Gia hạn</a>
                                                @endif
                                            
                                            @else
                                            <a target="_blank" href="{{$admin}}" class="btn btn-theme border btn-sm">Quản trị</a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                @if ($loop->last || $loop->index % 2 == 1)
                                    </div>
                                @endif
                            @endforeach

                            {{$userServices->links($_template.'pagination')}}
                        @else
                        <div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
                        @endif
                    </div>
                </div>
           </div>
       </div>
    </div>
@endsection
