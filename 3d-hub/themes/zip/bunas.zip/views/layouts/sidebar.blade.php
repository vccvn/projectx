<!DOCTYPE html>
<html lang="vi">

<head>
    <!-- ========== Meta Tags ========== -->
    
    @include($_lib.'head')

</head>

<body>

    {!! $html->top->embeds !!}

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Header 
    ============================================= -->
    @include($_template.'header')   
    <!-- End Header -->
    <!-- Start Blog
    ============================================= -->
    @php
        $md = isset($module)?$module:$__env->yieldContent('module', 'blog');
        $sp = (isset($sidebar_pos)?$sidebar_pos:$__env->yieldContent('sidebar_pos', 'right')) != 'left' ? 'right' : 'left';
        $sb = isset($sidebar)?$sidebar:$__env->yieldContent('sidebar', 'post');
        $cl = isset($module_class)?$module_class:$__env->yieldContent('module_class', 'full-blog');
        $bc = isset($show_breadcrumb)?$show_breadcrumb:$__env->yieldContent('show_breadcrumb');
        $pd = isset($main_padding)?$main_padding:$__env->yieldContent('main_padding', 'default');
        
    @endphp
    @if ($bc)
    @include($_template.'breadcrumbs')
    @endif
    
    <div class="{{$md}}-area main-area {{$cl}} {{$sp}}-sidebar {{$pd}}-padding  bg-gray">
        <div class="container">
            <div class="row">
                <div class="blog-items">
                    <div class="blog-content col-md-8">
                        @yield('content')
                    </div>
                    <!-- Start Sidebar -->
                    <div class="sidebar col-md-4">
                        @include($_template.'sidebar-'.$sb)
                    </div>
                    <!-- End Start Sidebar -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog -->


    <!-- Star Footer
    ============================================= -->

    @include($_template.'footer')     

    <!-- End Footer-->

    <!-- jQuery Frameworks
    ============================================= -->

    @include($_template.'js')
    {!! $html->bottom->embeds !!}
    

</body>

</html>