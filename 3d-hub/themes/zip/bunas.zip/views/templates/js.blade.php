

    <script src="{{theme_js('jquery-1.12.4.min.js')}}"></script>
    <script src="{{theme_js('bootstrap.min.js')}}"></script>
    <script src="{{theme_js('equal-height.min.js')}}"></script>
    <script src="{{theme_js('jquery.appear.js')}}"></script>
    <script src="{{theme_js('jquery.easing.min.js')}}"></script>
    <script src="{{theme_js('jquery.magnific-popup.min.js')}}"></script>
    <script src="{{theme_js('modernizr.custom.13711.js')}}"></script>
    <script src="{{theme_js('owl.carousel.min.js')}}"></script>
    <script src="{{theme_js('wow.min.js')}}"></script>
    <script src="{{theme_js('progress-bar.min.js')}}"></script>
    <script src="{{theme_js('isotope.pkgd.min.js')}}"></script>
    <script src="{{theme_js('imagesloaded.pkgd.min.js')}}"></script>
    <script src="{{theme_js('count-to.js')}}"></script>
    <script src="{{theme_js('bootsnav.js')}}"></script>
 
    @include($_lib.'js')

    <script src="{{theme_js('main.js')}}"></script>


    <script>
        window.bunasUrls = {!!
            json_encode([
                'base' => route('home'),
                'theme_asset' => theme_asset() 
            ])
        !!};
    </script>
