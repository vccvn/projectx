@php
    $page_title = isset($page_title)?$page_title:$__env->yieldContent('page_title');
    $header = $options->theme->header;
    $type = isset($breakcrumb_type)?$breakcrumb_type:$__env->yieldContent('breakcrumb_type');
@endphp


    @if ($type == 2)
        <div class="breadcrumb-2">
            <div class="container">
                <ul class="breadcrumb">
                    @if ($breakcrumbs = $helper->getBreakcrumbs())
                        @foreach ($breakcrumbs as $item)
                            <li @if ($loop->last) class="active" @endif>
                                @if ($loop->last)
                                {{$item->text}}
                                @elseif($loop->first)
                                <a href="{{$item->url}}"><i class="fas fa-home"></i> {{$item->text}}</a>
                                @else
                                <a href="{{$item->url}}"><strong>{{$item->text}}</strong></a>
                                @endif
                            </li>
                        @endforeach
                    @endif
                </ul>
            </div>
        </div>
    

    
    @else
    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area shadow dark bg-fixed text-center text-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>{{$page_title}}</h1>
                    <ul class="breadcrumb">
                        @if ($breakcrumbs = $helper->getBreakcrumbs())
                            @foreach ($breakcrumbs as $item)
                                <li @if ($loop->last) class="active" @endif>
                                    @if ($loop->last)
                                    {{$item->text}}
                                    @elseif($loop->first)
                                    <a href="{{$item->url}}"><i class="fas fa-home"></i> {{$item->text}}</a>
                                    @else
                                    <a href="{{$item->url}}"><strong>{{$item->text}}</strong></a>
                                    @endif
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

        
    @endif