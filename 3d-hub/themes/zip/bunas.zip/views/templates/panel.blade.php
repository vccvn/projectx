<div class="sidebar-item category">
    <div class="title">
        <h4>Panel</h4>
    </div>
    <div class="sidebar-info">
        <ul>
            @foreach ($settings as $sk => $item)
                <li><a class="" href="{{route('client.account.settings', ['tab' => $item->slug])}}">{{$item->title}}</a></li>
            @endforeach
            <li><a class="" href="{{route('client.services.list')}}">Dịch vụ</a></li>
            <li><a class="" href="{{route('client.services.add')}}">Thêm dịch vụ</a></li>
            
            <li><a class="" href="{{route('client.account.logout')}}">Thoát</a></li>
        </ul>
    </div>
</div>