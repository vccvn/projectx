<aside>
     {!! $html->sidebar_project->components !!}
</aside>