

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('img/favicon.png')}}" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="{{theme_css('bootstrap.min.css')}}" rel="stylesheet" />
    <link href="{{theme_css('font-awesome.min.css')}}" rel="stylesheet" />
    <link href="{{theme_css('themify-icons.css')}}" rel="stylesheet" />
    <link href="{{theme_css('magnific-popup.css')}}" rel="stylesheet" />
    <link href="{{theme_css('owl.carousel.min.css')}}" rel="stylesheet" />
    <link href="{{theme_css('owl.theme.default.min.css')}}" rel="stylesheet" />
    <link href="{{theme_css('animate.css')}}" rel="stylesheet" />
    <link href="{{theme_css('bootsnav.css')}}" rel="stylesheet" />
    <link href="{{theme_css('style.css')}}" rel="stylesheet">
    <link href="{{theme_css('responsive.css')}}" rel="stylesheet" />
    <link href="{{theme_css('custom.min.css')}}" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="{{theme_js('html5/html5shiv.min.js')}}"></script>
      <script src="{{theme_js('/html5/respond.min.js')}}"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&amp;display=swap" rel="stylesheet">
      @php
          
      $header = $options->theme->header;
      @endphp
    <style>
        .breadcrumb-area{
            background-image: url({{
            $__env->yieldContent('page_header_image', $header->page_header_background(theme_asset('img/banner/22.jpg')))
            }}); 
            padding: {{$header->page_header_padding_y(160)}}px 0;
        }
        .breadcrumb-area .breadcrumb{
            bottom: {{$header->page_header_breadcrumb_bottom(-180)}}px;
        }
        @media only screen and (max-width: 767px){
            .breadcrumb-area {
                padding: 50px 0;
            }
            .breadcrumb-area .breadcrumb{
                bottom: 0 !important;
            }
        }
        @media only screen and (max-width: 419px){
            .breadcrumb-area {
                padding: 30px 0 10px 0;
                background: transparent;
                text-align: left;
            }
            .breadcrumb-area.shadow.dark::after{
                background: transparent;
            }
            .breadcrumb-area h1{
                font-size: 25px;
                color: black;
                text-align: left;
            }
            .breadcrumb-area .breadcrumb{
                bottom: 0 !important;
                padding: 0;
            }
            .breadcrumb-area .breadcrumb::after {
                background: transparent;
            }
            .breadcrumb-area .breadcrumb a, .breadcrumb-area .breadcrumb li {
                color: #000;
            }
        }

  </style>