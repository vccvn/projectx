<aside>
    
{{-- 
    <div class="sidebar-item archives">
        <div class="title">
            <h4>Archives</h4>
        </div>
        <div class="sidebar-info">
            <ul>
                <li><a href="#">Aug 2018</a></li>
                <li><a href="#">Sept 2018</a></li>
                <li><a href="#">Nov 2018</a></li>
                <li><a href="#">Dec 2018</a></li>
            </ul>
        </div>
    </div>
    <div class="sidebar-item gallery">
        <div class="title">
            <h4>Gallery</h4>
        </div>
        <div class="sidebar-info">
            <ul>
                <li>
                    <a href="#">
                        <img src="assets/img/portfolio/1.jpg" alt="thumb">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="assets/img/portfolio/2.jpg" alt="thumb">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="assets/img/portfolio/3.jpg" alt="thumb">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="assets/img/portfolio/4.jpg" alt="thumb">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="assets/img/portfolio/5.jpg" alt="thumb">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="assets/img/portfolio/6.jpg" alt="thumb">
                    </a>
                </li>
            </ul>
        </div>
    </div>

     --}}

     {!! $html->sidebar_post->components !!}
</aside>