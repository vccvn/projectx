<?php

if(!function_exists('bunas_menu')){
    function bunas_menu($position = null, $attrs = [], $options = [], $action = null){
        $menu = Helper::getCustomMenu($position, 2, $attrs, $options, $action);
        
        // $menu->addAction(function($item, $link, $sub){
            
        // });
        return $menu;
    }
}


if(!function_exists('bunas_menu_primary_style')){
    function bunas_menu_primary_style($position = null, $attrs = [], $options = [], $action = null){
        $menu = Helper::getCustomMenu($position, 2, $attrs, $options, $action);
        
        $menu->addAction(function($item, $link, $sub){
            if($item->hasSubMenu()){
                $item->addClass('dropdown');
                $link->addClass('dropdown-toggle');
                $link->attr('data-toggle', 'dropdown');
                $item->sub->addClass('dropdown-menu');
            }
            if($item->isActive()){
                $link->addClass('active');
            }
            
        });
        return $menu;
    }
}




if(!function_exists('bunas_primary_menu')){
    function bunas_primary_menu($attrs = [], $options = [], $action = null){
        return bunas_menu_primary_style('primary', $attrs, $options, $action);
    }
}


if(!function_exists('bunas_section_attrs')){
    function bunas_section_attrs($section, $default = []){
        $tag = html('div', null, $default);
        $style = $tag->style;
        if($style) $style .= ';';

        if($section->class_name){
            $tag->addClass($section->class_name);
        }
        

        if($section->bg_default_color && $section->bg_default_color != 'none'){
            $tag->addClass('bg-'.$section->bg_default_color);
        }

        if($section->bg_color){
            $style .= 'background-color: '.$section->bg_color;
        }
        if($section->bg_image){
            $style .= 'background-image: url('.$section->bg_color .');';
            if($section->bg_position){
                $tag->addClass('bg-'.$section->bg_position);
            }
            if($section->bg_half){
                $tag->addClass('half-bg-light');
            }
        }

        if($section->advance && is_array($section->advance)){
            $tag->addClass(implode(' ', $section->advance));
        }
        return $tag->attrsToStr();
    }
}

